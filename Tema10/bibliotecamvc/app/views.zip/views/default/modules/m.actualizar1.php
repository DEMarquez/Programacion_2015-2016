
 <form action="index.php" method="post">
		 <table border="0" cellspacing="4" cellpadding="0" class="tabla">
  <tr>
    <td>Buscar por: </td>
    <td><label>
      Dni:
      <input type="text" name="dni" value="dni">
    </label></td>
    <td><label>
      <input type="submit" name="buscarActualizar" value="   Buscar   " />
    </label></td>
  </tr>
</table>
</form>

