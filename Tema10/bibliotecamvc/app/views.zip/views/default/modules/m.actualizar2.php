

<form action="index.php" method="post">
     <table border="0" cellspacing="4" cellpadding="0" class="tabla">
  <tr>
    <td>Buscar por: </td>
    <td><label>
      Dni:
      <input type="text" name="dni" value="#dni#" >
    </label></td>
    <td><label>
      <input type="submit" name="buscarActualizar" value="   Buscar   " />
    </label></td>
    
  </tr>
</table>



  <table border="0" cellspacing="4" cellpadding="0" class="tabla">
  <tr>
  <td><label>
  Nombre:<input type="text" name="nombre" value="#nombre#" readonly>
  </label></td>
  <td><label>
  Apellido 1:<input type="text" name="apellido1" value="#apellido1#">
  </label></td>
  <td><label>
  Apellido 2:<input type="text" name="apellido2" value="#apellido2#">
  </label></td>
  <td><label>
  Facultad:<input type="text" name="facultad" value="#facultad#">
  </label></td>
  <td><label>
  <input type="submit" name="actualizar" value="Actualizar">
  </label></td>
</form>

