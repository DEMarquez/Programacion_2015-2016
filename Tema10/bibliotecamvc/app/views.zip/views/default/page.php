<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>MVC - by Mouse</title>
<link rel="stylesheet" type="text/css" href="app/views/default/css/estilo.css"/>
</head>
<body>
<div id="wrapper">
		<!-- header  -->
        <div id="header">		 
		   	<div style=" margin:20px 0 0 0; text-align:center;">
				<h1>MVC</h1>		 			
				<h1>#TITLE#</h1>
			</div>
		</div>
		<!-- end: header  -->		
		<!-- columna izquierda  -->
        <div id="leftcolumn">		 
		  <div id="menu">
  			<ul>
    			<li><a href="index.php" >Principal</a></li>
    			<li><a href="index.php?action=buscar">Buscar usuarios</a></li>
    			<li><a href="index.php?action=insertar">Insertar usuario</a></li>
    			<li><a href="index.php?action=actualizar">Actualizar usuario</a></li>
    			<li><a href="index.php?action=history">Historia de la biblioteca</a></li>
  			</ul>
		  </div>
		</div>
		<!-- end: columna izquierda  -->		 
		<!-- contenido -->
		<div id="content">		
		  #CONTENIDO#		 
		</div>
		<!-- end: contenido -->		 
</div>
</body>
</html>
